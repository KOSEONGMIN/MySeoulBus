console.log('Hi')

//var xhr = new XMLHttpRequest();
//var url = 'http://ws.bus.go.kr/api/rest/buspos/getBusPosByRtid'; /*URL*/
//var queryParams = '?' + encodeURIComponent('serviceKey') + '='+'7e8%2FOjDlwHSrpPcWvWNvvo7wfF0v1eWF%2BA%2B%2BY75zU2IAuWX96F8oFCWmnUkwc84IbAX0NrpjbejFvJMjz0VWzw%3D%3D'; /*Service Key*/
//queryParams += '&' + encodeURIComponent('busRouteId') + '=' + encodeURIComponent('100100201'); /*bus route id*/
//console.log('REQUEST URL: ' + url + queryParams)
//xhr.open('GET', url + queryParams);
//xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
//xhr.onreadystatechange = function () {
//    if (this.readyState == 4) {
//	console.log(this.responseXML)
//    }
//};

//xhr.send('');

const axios = require('axios');

// Make a request for a user with a given ID
axios.get('http://ws.bus.go.kr/api/rest/busRouteInfo/getBusRouteList?serviceKey=7e8%2FOjDlwHSrpPcWvWNvvo7wfF0v1eWF%2BA%2B%2BY75zU2IAuWX96F8oFCWmnUkwc84IbAX0NrpjbejFvJMjz0VWzw%3D%3D&strSrch=2224')
  .then(function (response) {
    // handle success
    console.log(response);
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })
  .then(function () {
    // always executed
  });
