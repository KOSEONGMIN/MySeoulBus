var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
//  res.send('route api url test');
	var xhr = new XMLHttpRequest();
	var url = 'http://ws.bus.go.kr/api/rest/buspos/getBusPosByRtid'; /*URL*/
	var queryParams = '?' + encodeURIComponent('serviceKey') + '='+'7e8%2FOjDlwHSrpPcWvWNvvo7wfF0v1eWF%2BA%2B%2BY75zU2IAuWX96F8oFCWmnUkwc84IbAX0NrpjbejFvJMjz0VWzw%3D%3D'; /*Service Key*/
	queryParams += '&' + encodeURIComponent('busRouteId') + '=' + encodeURIComponent('100100201'); /*bus route id*/
	console.log('REQUEST URL: ' + url + queryParams)
	xhr.open('GET', url + queryParams);
	//xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
	xhr.onreadystatechange = function () {
		if (this.readyState == 4) {
			console.log(this.responseXML)
			res.send(this.responseXML);
		}
    	}
	xhr.send('');
});

module.exports = router;
