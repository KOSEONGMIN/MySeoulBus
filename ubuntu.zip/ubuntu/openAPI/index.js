const express = require("express")
const bodyParser = require("body-parser")
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const convert = require('xml-js');

const server = express();

server.use(bodyParser.json())
server.use(cors())

server.use(express.static(path.join(__dirname, 'public')));
var routeAPIKey = '7e8%2FOjDlwHSrpPcWvWNvvo7wfF0v1eWF%2BA%2B%2BY75zU2IAuWX96F8oFCWmnUkwc84IbAX0NrpjbejFvJMjz0VWzw%3D%3D'
var busPosAPIKey = '7e8%2FOjDlwHSrpPcWvWNvvo7wfF0v1eWF%2BA%2B%2BY75zU2IAuWX96F8oFCWmnUkwc84IbAX0NrpjbejFvJMjz0VWzw%3D%3D'

// 버스 노선 정보 (busnum -> routeid)
server.get("/route",(req,res)=>{
//    res.json(users);
	axios.get('http://ws.bus.go.kr/api/rest/busRouteInfo/getBusRouteList?serviceKey=' + routeAPIKey + '&strSrch=' + req.query.busnum)
	.then(function (response) {
    // handle success
		var result = JSON.parse(convert.xml2json(response.data, {compact: true, spaces: 4}))
		var busRouteId = result.ServiceResult.msgBody.itemList.busRouteId._text
		console.log(busRouteId)
		res.json(busRouteId);
	})
	.catch(function (error) {
    // handle error
	console.log(error);
	})
	.then(function () {
    // always executed
	});
})

// 버스 노선 정보 (routeid -> latlng data)
server.get("/bus",(req,res)=>{
//    res.json(users);
        axios.get('http://ws.bus.go.kr/api/rest/buspos/getBusPosByRtid?serviceKey=' + busPosAPIKey + '&busRouteId=' + req.query.routeid)
        .then(function (response) {
    // handle success
                var result = JSON.parse(convert.xml2json(response.data, {compact: true, spaces: 4}))
//                console.log(result.ServiceResult.msgBody.itemList)
		busList = result.ServiceResult.msgBody.itemList
		var busPosList = []
		for(let bus of busList){
	                busPosList.push([bus.gpsY._text, bus.gpsX._text])
                }
		console.log('busPosList cnt: ', busPosList.length)
                res.json(busPosList);
        })
        .catch(function (error) {
    // handle error
        console.log(error);
        })
        .then(function () {
    // always executed
        });
})

server.listen(8000, ()=>{
    console.log("the server is running: port 8000")
})
